"""Local, isolated experiment adapter. Upstream source/data are never modified."""
from __future__ import annotations
import contextlib
import copy
from dataclasses import asdict
import io
import json
import math
from pathlib import Path
import sys

ENGINE = Path(__file__).resolve().parents[1] / "nikke-calc"
sys.path.insert(0, str(ENGINE))
from runner import sim
from calculator import buff_manager as bm_mod, timeline

SQUAD = ["토브", "솔린 : 프로스트 티켓", "아르카나 : 포츈 메이트", "프리바티 : 언카인드 메이드", "소다 : 트윙클링 바니"]
FAN_NAME = "레오나 이격 · 시험안"
SPIDER = next((ENGINE / "data/boss_scripts").glob("*S40*.json"))
DEFAULTS = {
    "duration": 60, "seed": 7, "rng_mode": "expected", "gauge": "accumulate", "boss": "custom", "boss_source": "",
    "atk": 114344, "def": 31784, "distance": 15, "code": "풍압",
    "core_mode": "reference", "core_px": 0, "core_windows": [],
    "patterns": [{"start": 8, "every": 8, "coeff": 250, "target": "all", "hits": 1, "interval": 0.3, "pierce": False}],
    "heal_mode": "shots", "heal_value": 5, "heal_every": 5, "heal_targets": 2,
    "cdr": 7.48, "burst_cd": 40, "burst_policy": "never", "burst_heal": 25,
    "damage_reduction": 15, "reduction_duration": 5, "baseline_burst": "tove",
}

def number(obj, key, lo, hi, integer=False):
    value = obj[key]
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{key}: 유효한 숫자가 필요합니다.")
    if not lo <= value <= hi or (integer and value != int(value)):
        raise ValueError(f"{key}: {lo}~{hi} 범위{'의 정수' if integer else ''}여야 합니다.")
    return int(value) if integer else float(value)

def validate(raw):
    if not isinstance(raw, dict):
        raise ValueError("설정은 JSON 객체여야 합니다.")
    unknown = set(raw) - set(DEFAULTS) - {"teams", "custom"}
    if unknown:
        raise ValueError(f"알 수 없는 설정: {sorted(unknown)}")
    p = copy.deepcopy(DEFAULTS)
    p.update(raw)
    import boss_catalog
    if not isinstance(p['boss_source'],str) or p['boss_source'] and not boss_catalog.find(p['boss_source']):
        raise ValueError('보스 자료 선택이 올바르지 않습니다.')
    for k, lo, hi, integer in [
        ("duration", 10, 180, True), ("seed", 0, 999999, True),
        ("atk", 0, 5000000, False), ("def", 0, 1000000, False), ("distance", 1, 100, False),
        ("core_px", 0, 1000, True),
        ("heal_value", 0, 100, False), ("heal_every", 1, 60, True), ("heal_targets", 1, 5, True),
        ("cdr", 0, 15, False), ("burst_cd", 20, 60, True), ("burst_heal", 0, 100, False),
        ("damage_reduction", 0, 90, False), ("reduction_duration", 0.1, 20, False),
    ]:
        p[k] = number(p, k, lo, hi, integer)
    for k, options in {
        "core_mode": ["reference", "none", "manual"],
        "rng_mode": ["expected", "random"],
        "gauge": ["fixed", "accumulate"], "boss": ["custom", "dummy", "spider", "library"],
        "code": ["풍압", "작열", "수냉", "전격", "철갑"], "heal_mode": ["shots", "time"],
        "burst_policy": ["never", "every3"], "baseline_burst": ["tove", "soline3"],
    }.items():
        if p[k] not in options:
            raise ValueError(f"{k}: 지원하지 않는 값입니다.")
    if not isinstance(p['core_windows'],list) or len(p['core_windows'])>20:
        raise ValueError('코어 노출 구간은 최대20개입니다.')
    for w in p['core_windows']:
        if not isinstance(w,list) or len(w)!=2 or any(type(v) not in (int,float) or not math.isfinite(v) for v in w) or not 0<=w[0]<w[1]<=180:
            raise ValueError('코어 구간은 0~180초에서 시작 < 종료여야 합니다.')
    if p['core_mode']=='manual' and not p['core_px']:
        raise ValueError('코어 직접 설정은 크기를 1px 이상 입력하세요.')
    if p['boss']=='library':
        b=boss_catalog.find(p['boss_source'])
        if not b or b['raid']==40:
            raise ValueError('자료 기반 고유 패턴의 보스를 선택하세요.')
        if not b['model_summary']['attacks']:
            raise ValueError('이 보스는 아직 실행 가능한 공격이 없습니다.')
    if not isinstance(p["patterns"], list) or not 1 <= len(p["patterns"]) <= 6:
        raise ValueError("공격 패턴은 1~6개까지 가능합니다.")
    for row in p["patterns"]:
        if not isinstance(row, dict) or set(row) - {"name"} != {"start", "every", "coeff", "target", "hits", "interval", "pierce"}:
            raise ValueError("공격 패턴의 항목이 올바르지 않습니다.")
        if "name" in row and (not isinstance(row["name"],str) or len(row["name"])>120):
            raise ValueError("공격 이름은 120자 이하여야 합니다.")
        for key, lo, hi, integer in [("start", 0, 180, False), ("every", 1, 180, False), ("coeff", 0, 10000, False), ("hits", 1, 10, True), ("interval", 0.05, 5, False)]:
            row[key] = number(row, key, lo, hi, integer)
        if row["target"] not in ["all", "random:1", "top_atk:1", "slot:1", "slot:2", "slot:3", "slot:4", "slot:5"] or type(row["pierce"]) is not bool:
            raise ValueError("공격 대상 또는 관통 설정이 잘못되었습니다.")
    if "teams" in p or "custom" in p:
        import loadout
        loadout.validate(p.get("teams"), p.get("custom"))
    return p

def make_boss(p):
    import boss_core
    if p["boss"] == "spider":
        if p.get('core_mode','reference')!='manual':return str(SPIDER)
        from runner.boss import build_enemy
        return boss_core.apply(build_enemy(json.loads(SPIDER.read_text(encoding='utf-8'))),p)
    core_params=p
    if p['boss']=='library':
        import boss_catalog
        b=boss_catalog.find(p['boss_source'])
        p=copy.deepcopy(p)
        p.update({k:b[k] for k in ['atk','def','code']})
        p['boss']='custom'
        p['patterns']=[{'name':a['name'], 'start':a['start'], 'every':a['every'],
                        'interval':a['interval'], **a['spec']} for a in b['model_summary']['attacks']]
    boss = {"atk": p["atk"], "def": p["def"], "code": p["code"], "distance": p["distance"], "core_px": 0}
    # A nonattacking idle pattern keeps enemy targeting/geometry mode identical in dummy and custom.
    nodes = [{"id": "가상 시험 구간", "kind": "idle", "until": {"time": p["duration"] + 1}}]
    if p["boss"] == "custom":
        for i, row in enumerate(p["patterns"]):
            t = row["start"]
            n = 1
            while t < p["duration"]:
                nodes.append({"id": f"{row.get('name') or '공격 '+str(i+1)} · {n}", "kind": "attack", "after": ["start"], "delay": round(t, 5),
                    "until": {"time": (row["hits"]-1)*row["interval"] + 0.1},
                    "spec": {k: row[k] for k in ["coeff", "target", "hits", "interval", "pierce"]}})
                n += 1
                t += row["every"]
    boss["patterns"] = nodes
    return boss_core.apply(boss,core_params)

def fan_effects(p):
    def effect(name, stat, value, timing, typ="instant", **extra):
        return {"source": "스킬3" if timing == "burst_cast" else "스킬1", "type": typ,
            "name": "시험안 · " + name, "stat": stat, "fixed_value": value,
            "trigger": {"timing": [timing], "condition": []}, "target": "all_allies", **extra}
    timing = f"on_attack_count:{p['heal_every']}" if p["heal_mode"] == "shots" else f"every:{p['heal_every']}s"
    return [
        effect("반복 회복", "heal_hp_pct", p["heal_value"], timing, scaling="max_hp", target=f"allies_lowest_hp:{p['heal_targets']}"),
        # Same cooldown-buff semantics as Frost Ticket Soline; does not stack each Full Burst.
        effect("재사용 시간 감소", "burst_cooldown", p["cdr"], "full_burst_start", "buff", duration=-1, polarity="beneficial"),
        effect("버스트 회복", "heal_hp_pct", p["burst_heal"], "burst_cast", scaling="max_hp"),
        effect("버스트 피해 감소", "received_dmg_pct", -p["damage_reduction"], "burst_cast", "buff", duration=p["reduction_duration"], polarity="beneficial"),
    ]

class Observer:
    """Read-only HP sampling + heal-handler instrumentation; no combat state writes."""
    def __init__(self):
        self.points = []
        self.min_hp = {}
        self.heals = []
        self.manager = None
        self.last_sample = -1.0
        self.originals = {}

    def sample(self, bm, t, force=False):
        self.manager = bm
        h = {n: round(max(0, bm.state.get("hp", {}).get(n, 0)) / max(1, bm.effective_max_hp(n)) * 100, 3) for n in bm.squad_names}
        for n, pct in h.items():
            self.min_hp[n] = min(self.min_hp.get(n, 100), pct)
        if force or t - self.last_sample >= .25 - 1e-6:
            self.points.append({"t": round(max(0, t), 4), "hp": h})
            self.last_sample = t

    def install(self):
        cls = bm_mod.BuffManager
        for name in ["tick", "sync_hp", "register_instant_handler"]:
            self.originals[name] = getattr(cls, name)
        observer = self
        def tick(bm, t):
            ret = observer.originals["tick"](bm, t)
            observer.sample(bm, t)
            return ret
        def sync_hp(bm, name):
            # Record the threshold-crossing HP before emergency heals triggered by sync_hp.
            observer.sample(bm, bm._cur_t, force=True)
            ret = observer.originals["sync_hp"](bm, name)
            observer.sample(bm, bm._cur_t, force=True)
            return ret
        def register(bm, stat, handler):
            if stat == "heal_hp_pct":
                original_handler = handler
                def handler(eff, caster, t, val):
                    targets = [n for n in bm._resolve_target(eff.get("target", "self"), caster) if n in bm.squad_names]
                    before = {n: bm.state["hp"].get(n, 0) for n in targets}
                    potential = {}
                    for n in targets:
                        base = bm.effective_max_hp(caster) if eff.get("scaling") == "max_hp" else bm.state["base_stats"].get(n, {}).get("hp", 0)
                        potential[n] = max(0, base * val / 100 * bm.heal_received_mult(n, t))
                    result = original_handler(eff, caster, t, val)
                    for n in targets:
                        gain = max(0, min(potential[n], bm.state["hp"].get(n, 0) - before[n]))
                        observer.heals.append({"t": round(t, 4), "caster": caster, "target": n, "name": eff.get("name", ""), "effective": round(gain), "overheal": round(max(0, potential[n]-gain))})
                    return result
            return observer.originals["register_instant_handler"](bm, stat, handler)
        cls.tick, cls.sync_hp, cls.register_instant_handler = tick, sync_hp, register

    def restore(self):
        for name, value in self.originals.items():
            setattr(bm_mod.BuffManager, name, value)

def run_one(p, variant):
    if "teams" in p:
        return run_general(p, variant)
    members = list(SQUAD)
    prototype = variant == "prototype"
    if prototype:
        members[1] = "레오나"
    req = {"schema_version": 2, "squad": members,
        "sim": {"duration": p["duration"], "seed": p["seed"], "expected": p["rng_mode"] == "expected", "burst_gauge_mode": p["gauge"]},
        "boss": make_boss(p), "operation": {"control_mode": "solo"}}
    # Retain all upstream character-specific equipment, favorite items and control layers.
    run = sim.prepare(req)
    saved_effects = bm_mod._PARSED_SKILLS["레오나"]
    saved_tl_effects = timeline._PARSED_SKILLS["레오나"]
    saved_cd = timeline._NIKKE["레오나"]["burst_cooldown"]
    if prototype:
        effects = fan_effects(p)
        bm_mod._PARSED_SKILLS["레오나"] = effects
        timeline._PARSED_SKILLS["레오나"] = effects
        timeline._NIKKE["레오나"]["burst_cooldown"] = p["burst_cd"]
        run.config.pop("burst_sequence", None)
        run.config["burst_pattern"] = {"레오나": "every:3"} if p["burst_policy"] == "every3" else {}
        if p["burst_policy"] == "never":
            run.config["no_burst_char"] = "레오나"
    elif p["baseline_burst"] == "soline3":
        # Tove is normally the first B1. Defer it on cycles 3,6,... to Soline (cooldown fallback applies).
        run.config.pop("burst_sequence", None)
        run.config["burst_pattern"] = {"토브": [i for i in range(1, 100) if i % 3]}
        run.config.pop("no_burst_char", None)
    else:
        run.config["no_burst_char"] = SQUAD[1]
    observer = Observer()
    observer.install()
    try:
        result = sim.execute(run)
        if observer.manager:
            observer.sample(observer.manager, result.duration, force=True)
        out = sim.payload(run, result)
        stats = observer.manager.state.get("base_stats", {}) if observer.manager else {}
        out.update({"variant": variant, "display_names": {"레오나": FAN_NAME} if prototype else {},
            "hp": observer.points, "min_hp": observer.min_hp,
            "heals": observer.heals, "squad_hits": [asdict(x) for x in result.squad_hits],
            "boss_events": [asdict(x) for x in result.boss_log],
            "burst_events": [asdict(x) for x in result.log.burst_log],
            "base_stats": stats, "resolved_squad": run.squad, "resolved_config": run.config,
            "effects": fan_effects(p) if prototype else [],
            "final_hp": observer.points[-1]["hp"] if observer.points else {},
            "engine_commit": "23164e4a88fe46af609cc99b0de38a98313a5f4d"})
        return out
    finally:
        observer.restore()
        bm_mod._PARSED_SKILLS["레오나"] = saved_effects
        timeline._PARSED_SKILLS["레오나"] = saved_tl_effects
        timeline._NIKKE["레오나"]["burst_cooldown"] = saved_cd

def compare(raw):
    p = validate(raw)
    result={"settings": p, "baseline": run_one(p, "baseline"), "prototype": run_one(p, "prototype")}
    import boss_core
    result['core_conditions']=boss_core.resolved(p)
    for key in ('baseline','prototype'):
        result[key]['core_conditions']=copy.deepcopy(result['core_conditions'])
        result[key].setdefault('warnings',[]).append(result['core_conditions']['message'])
    if p['boss_source']:
        import boss_catalog
        result['boss_reference']=copy.deepcopy(boss_catalog.find(p['boss_source']))
        if p['boss']=='library':result['boss_model']=copy.deepcopy(result['boss_reference']['model_summary'])
    if p['boss'] != 'dummy':
        # Persist the validity boundary with exported results, not only the form.
        result['incoming_validation']={
            'status':'unverified', 'usable_for_healing_decision':False,
            'damage_measured':False,
            'timing_basis':'video_approximation' if p['boss']=='spider' else
                           'synthetic' if p['boss']=='library' else 'user_defined',
            'message':'보스 피격량은 실전 미검증입니다. 이 결과의 생존 여부·회복량으로 힐 필요성을 판단할 수 없습니다.'}
        for key in ('baseline','prototype'):
            result[key].setdefault('warnings',[]).append(result['incoming_validation']['message'])
    return result

def run_general(p, variant):
    import loadout
    import leona_circus
    from runner import spec
    team = p["teams"][0 if variant == "baseline" else 1]
    custom = p["custom"]
    has_custom = loadout.CUSTOM in team["members"]
    base = custom["base"]
    resolve = lambda n: base if n == loadout.CUSTOM else n
    members = [resolve(n) for n in team["members"]]
    saved = []
    observer = Observer()
    runtime = leona_circus.Runtime(members) if has_custom and custom.get('preset')==leona_circus.ID else None
    effects = runtime.effects if runtime else loadout.compile_effects(custom) if has_custom else []
    def replace(mapping, key, value):
        saved.append((mapping,key,mapping[key]))
        mapping[key]=value
    try:
        if has_custom:
            for mapping in [bm_mod._NIKKE, timeline._NIKKE, spec._nikke()]:
                metadata=copy.deepcopy(mapping[base])
                metadata.update(burst_stage=custom["stage"],burst_cooldown=custom["cooldown"],favorite_slots=[])
                replace(mapping,base,metadata)
            replace(bm_mod._PARSED_SKILLS,base,effects)
            replace(timeline._PARSED_SKILLS,base,effects)
        op={"control_mode":"solo"}
        if has_custom:op["auto"]=[base]  # No original-character tactics in a custom skill set.
        if team["no_burst"]:op["no_burst"]=resolve(team["no_burst"])
        req={"schema_version":2,"squad":members,"boss":make_boss(p),"operation":op,
            "chars":{n:{"favorite_stage":3 if enabled else 0} for n,enabled in team.get("favorites",{}).items()},
            "sim":{"duration":p["duration"],"seed":p["seed"],"expected":p["rng_mode"] == "expected","burst_gauge_mode":p["gauge"]}}
        run=sim.prepare(req)
        # User's cycle preference is deliberately stronger than auto-selected character defaults.
        if team["every3"]:
            who=resolve(team["every3"])
            run.config.pop("burst_sequence",None)
            patterns=run.config.setdefault("burst_pattern",{})
            stage=timeline._NIKKE[who]["burst_stage"]
            for n in members:
                if timeline._NIKKE[n]["burst_stage"]==stage:
                    patterns[n]="every:3" if n==who else [i for i in range(1,200) if i%3]
        if runtime and team.get('curtain_cycles'):
            cycles=set(team['curtain_cycles'])
            run.config.pop('burst_sequence',None)
            patterns=run.config.setdefault('burst_pattern',{})
            for name in members:
                if str(timeline._NIKKE[name]['burst_stage'])=='2':
                    patterns[name]=sorted(cycles) if name==base else [i for i in range(1,201) if i not in cycles]
        observer.install()
        if runtime:runtime.install()
        result=sim.execute(run)
        if observer.manager:observer.sample(observer.manager,result.duration,force=True)
        out=sim.payload(run,result)
        warning=[]
        active=[n for n in members if n!=resolve(team["no_burst"])]
        stages={str(timeline._NIKKE[n]["burst_stage"]) for n in active}
        if "A" not in stages and not {"1","2","3"}.issubset(stages):
            warning.append("사용 가능한 버스트 단계가 부족합니다. 단계 변경/재진입 캐릭터는 실제 버스트 로그로 확인하세요.")
        if has_custom:
            warning.append(f"사용자 정의 '{custom['name']}'는 {base}의 기본 능력치·무기·코드·장비를 빌리며 원본 스킬과 전용 운용은 제거합니다. 화면의 효과만 적용한 시험 모델입니다.")
        out["warnings"].extend(warning)
        out.update({"variant":variant,"display_names":{base:custom["name"].strip()+" [시험]"} if has_custom else {},
            "hp":observer.points,"min_hp":observer.min_hp,"heals":observer.heals,
            "squad_hits":[asdict(x) for x in result.squad_hits],"boss_events":[asdict(x) for x in result.boss_log],
            "burst_events":[asdict(x) for x in result.log.burst_log],
            "base_stats":observer.manager.state.get("base_stats",{}) if observer.manager else {},
            "resolved_squad":run.squad,"resolved_config":run.config,"effects":effects,
            "final_hp":observer.points[-1]["hp"] if observer.points else {},
            "engine_commit":"23164e4a88fe46af609cc99b0de38a98313a5f4d"})
        if runtime:
            out['design_preset']=leona_circus.ID
            out['design_audit']=runtime.audit
            out['design_spec']=leona_circus.DESIGN
            out['curtain_direct_hits']=[asdict(h) for h in result.hits if h.skill_name=='커튼콜 · 직접 피해']
            starts=[e for e in runtime.audit if e['event']=='showtime']
            if len(starts)>1 and all(e['stack']==1 for e in starts):
                out['warnings'].append('커튼콜 반복 사용으로 스포트라이트가 1중첩에 머물렀습니다. 펠릿·명중률·재장전 보상이 발동하지 않았습니다. 다른 B2 우선 운용 또는 커튼콜 사용 회차를 지정해 비교하세요.')
        return out
    finally:
        if runtime:runtime.restore()
        observer.restore()
        for mapping,key,value in reversed(saved):mapping[key]=value

if __name__ == "__main__":
    try:
        raw = json.load(sys.stdin)
        messages = io.StringIO()
        with contextlib.redirect_stdout(messages):
            result = compare(raw)
        result["engine_messages"] = messages.getvalue()
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    except (Exception, SystemExit) as e:
        import traceback
        traceback.print_exc(file=sys.stderr)
        print(json.dumps({"error": str(e)}, ensure_ascii=False))
        sys.exit(1)
