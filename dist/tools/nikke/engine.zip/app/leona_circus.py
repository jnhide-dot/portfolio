"""Approved fan design, isolated from the source engine and ordinary custom skills."""
import copy
import json
from pathlib import Path
from calculator import buff_manager as bm_mod, timeline

ID = 'leona-circus-20261102'
DESIGN = json.loads((Path(__file__).parents[1] / 'design/leona-circus-approved-20261102.json').read_text(encoding='utf-8'))
PRESET = dict(name='레오나 이격 · 커튼콜', base='레오나', stage='2', cooldown=20, effects=[], preset=ID)


def effect(name, stat, value, timing='manual', target='allies_weapon:SG', duration=10, typ='buff', **kw):
    return dict(source='스킬3' if name.startswith('커튼콜') else '스킬2', name=name,
                stat=stat, fixed_value=value, type=typ, trigger={'timing':[timing], 'condition':[]},
                target=target, duration=duration, polarity='beneficial', **kw)


class Runtime:
    def __init__(self, members):
        self.members = members
        self.caster = PRESET['base']
        self.stacks = 1
        self.pending = None
        self.audit = []
        self.states = {}
        self.installed = False
        self.atk = effect('스포트라이트 · 공격력', 'atk_caster_based_pct', 5, 'battle_start', duration=-1)
        ramp = [copy.deepcopy(e) for e in bm_mod._PARSED_SKILLS['도라'] if e.get('stat') == 'burst_cooldown_reduce']
        if [e['fixed_value'] for e in ramp] != [1.82, 2.2, 2.6]:
            raise ValueError('버스트 쿨타임 감소 원본이 변경되었습니다. 확정안 검증이 필요합니다.')
        self.effects = ramp + [self.atk, effect('스포트라이트 · 회복', 'heal_hp_pct', 4.12,
                         'every:3s', 'allies_lowest_hp:2', typ='instant', scaling='max_hp')]

    def install(self):
        self.old_notify = bm_mod.BuffManager.notify
        self.old_activate = bm_mod.BuffManager._activate
        self.old_register = timeline._register_instant_handlers
        runtime = self

        def activate(bm, eff, caster, t, *args, **kwargs):
            if caster == runtime.caster:
                if eff.get('stat') == 'burst_cooldown_reduce':
                    runtime.audit.append(dict(t=t, event='cdr_ramp_activation', value=eff['fixed_value']))
                if eff.get('name') == '스포트라이트 · 회복':
                    eff = dict(eff, fixed_value=[4.12,5.15,6.18][runtime.stacks-1])
            return runtime.old_activate(bm, eff, caster, t, *args, **kwargs)

        def register(bm, char_states, burst_ctrl):
            runtime.states.update(char_states)
            return runtime.old_register(bm, char_states, burst_ctrl)

        def notify(bm, event, t, caster, **ctx):
            ret = runtime.old_notify(bm, event, t, caster, **ctx)
            runtime.on_event(bm, event, t, caster)
            return ret

        bm_mod.BuffManager._activate = activate
        bm_mod.BuffManager.notify = notify
        timeline._register_instant_handlers = register
        self.installed = True

    def on_event(self, bm, event, t, caster):
        n = self.stacks
        if caster == self.caster and event == 'burst_cast':
            self.pending = n
            buff = DESIGN['curtain_call']['attack_damage_buff_pct_per_stack_lv10'] * n
            coefficient = DESIGN['curtain_call']['damage_per_stack_by_level']['10'] * n
            bm._activate(effect('커튼콜 · 공격 대미지', 'atk_dmg_pct', buff), self.caster, t)
            bm._activate(effect('커튼콜 · 직접 피해', 'burst_damage', coefficient,
                                target='enemies_nearest:1', typ='damage'), self.caster, t)
            self.audit.append(dict(t=t, event='curtain_cast', stack=n, atk_dmg=buff, coefficient=coefficient))
        if caster == self.caster and event == 'full_burst_start':
            if n >= 2:
                for label, stat, value in [('펠릿','pellet_count',5), ('명중률','accuracy_pct',20)]:
                    bm._activate(effect('쇼타임 · '+label, stat, value, target='allies_weapon_top_atk:SG:2'), self.caster, t)
            if n == 3:
                bm._activate(effect('쇼타임 · 재장전', 'reload_speed_pct', 20,
                                    target='allies_weapon_top_atk:SG:2', duration=15), self.caster, t)
        # Resolve refill after every ally's full-burst-entry magazine effects.
        if caster == self.members[-1] and event == 'full_burst_start':
            if self.pending == 3:
                before = {name:dict(ammo=s.ammo,max_ammo=s._full_ammo(bm,t),reloading_until=s.reloading_until)
                          for name,s in self.states.items() if timeline._NIKKE[name]['weapon_type']=='SG'}
                bm._activate(effect('커튼콜 · 급탄','ammo_charge_pct',100,typ='instant'),self.caster,t)
                for name in before:
                    s = self.states[name]
                    if s.reloading_until > 0 and s.ammo >= s._full_ammo(bm,t):
                        s._cancel_reload(t,bm)
                after = {name:dict(ammo=self.states[name].ammo,max_ammo=self.states[name]._full_ammo(bm,t),
                                  reloading_until=self.states[name].reloading_until) for name in before}
                self.audit.append(dict(t=t,event='refill',before=before,after=after))
            self.audit.append(dict(t=t,event='showtime',stack=n,
                                   buffs={name:bm.get_buffs(name,'__enemy__',t) for name in self.members}))
        if caster == self.caster and event == 'full_burst_end':
            used = self.pending is not None
            self.stacks = 1 if used else min(3,n+1)
            self.pending = None
            self.atk['fixed_value'] = 5*self.stacks
            bm._bump_value_version()
            self.audit.append(dict(t=t,event='spotlight_end',before=n,after=self.stacks,curtain=used))

    def restore(self):
        if self.installed:
            bm_mod.BuffManager.notify = self.old_notify
            bm_mod.BuffManager._activate = self.old_activate
            timeline._register_instant_handlers = self.old_register
            self.installed = False
