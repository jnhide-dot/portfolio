"""Validated user-editable squads and a deliberately bounded custom-skill vocabulary."""
import copy
import math
from calculator import buff_manager as bm
from runner import spec
import leona_circus

CUSTOM = "__custom__"
STATS = {
    "heal_hp_pct": ("최대 체력 기준 회복", "instant", 100),
    "burst_cooldown": ("팀 버스트 재사용 시간 감소 (초)", "buff", 15),
    "atk_pct": ("공격력 증가 (%)", "buff", 500),
    "atk_caster_based_pct": ("시전자 공격력 기준 증가 (%)", "buff", 500),
    "atk_dmg_pct": ("공격 대미지 증가 (%)", "buff", 500),
    "core_dmg_pct": ("코어 대미지 증가 (%)", "buff", 500),
    "split_dmg_pct": ("분배 대미지 증가 (%)", "buff", 500),
    "pierce_dmg_pct": ("관통 대미지 증가 (%)", "buff", 500),
    "dot_dmg_pct": ("지속 대미지 증가 (%)", "buff", 500),
    "armor_break_dmg_pct": ("방어무시 대미지 증가 (%)", "buff", 500),
    "charge_dmg_pct": ("차지 대미지 증가 (%)", "buff", 500),
    "crit_rate": ("크리티컬 확률 증가 (%p)", "buff", 100),
    "crit_dmg": ("크리티컬 대미지 증가 (%)", "buff", 500),
    "damage_reduction": ("받는 피해 감소 (%)", "buff", 90),
    "burst_damage": ("공격력 기준 스킬 대미지 (%)", "damage", 10000),
}
TRIGGERS = {"passive": "상시", "battle_start": "전투 시작", "full_burst_start": "풀버스트 진입", "burst_cast": "자신의 버스트 사용", "shots": "일반 공격 N회", "time": "N초마다"}
TARGETS = {"all_allies": "아군 전체", "self": "자신", "allies_lowest_hp:2": "저체력 2명", "allies_lowest_hp:1": "저체력 1명", "allies_top_atk:2": "공격력 상위 2명", "allies_weapon:SG": "산탄총 아군", "allies_weapon:SR": "저격소총 아군", "allies_weapon:RL": "로켓런처 아군", "all_enemies": "적 전체"}

def row(stat, value, trigger, target="all_allies", duration=10, n=5):
    return dict(stat=stat, value=value, trigger=trigger, target=target, duration=duration, n=n)

DEFAULT_CUSTOM = {"name": "레오나 이격 · 시험안", "base": "레오나", "stage": "2", "cooldown": 40,
    "effects": [row("heal_hp_pct", 5, "shots", "allies_lowest_hp:2"), row("burst_cooldown", 7.48, "full_burst_start", duration=-1), row("heal_hp_pct", 25, "burst_cast"), row("damage_reduction", 15, "burst_cast", duration=5)]}
DEFAULT_TEAMS = [
    {"members": ["토브", "솔린 : 프로스트 티켓", "아르카나 : 포츈 메이트", "프리바티 : 언카인드 메이드", "소다 : 트윙클링 바니"], "no_burst": "솔린 : 프로스트 티켓", "every3": ""},
    {"members": ["토브", CUSTOM, "아르카나 : 포츈 메이트", "프리바티 : 언카인드 메이드", "소다 : 트윙클링 바니"], "no_burst": CUSTOM, "every3": ""},
]

def catalog():
    return {"characters": [{"name": n, "stage": str(d.get("burst_stage", "")), "weapon": d.get("weapon_type", ""), "code": d.get("element_code", ""), "has_favorite": bool(d.get("favorite_slots")), "preview": spec.is_preview(n)} for n,d in sorted(bm._NIKKE.items()) if n in bm._PARSED_SKILLS],
        "stats": [{"id": k, "label": v[0], "type": v[1], "max": v[2]} for k,v in STATS.items()],
        "triggers": TRIGGERS, "targets": TARGETS, "default_teams": DEFAULT_TEAMS, "default_custom": DEFAULT_CUSTOM,
        "presets": [copy.deepcopy(leona_circus.PRESET)]}

def numeric(value, lo, hi, label, integral=False):
    if type(value) not in (int,float) or not math.isfinite(value) or not lo <= value <= hi or (integral and value != int(value)):
        raise ValueError(f"{label}: {lo}~{hi} 범위의 {'정수' if integral else '숫자'}가 필요합니다.")
    return value

def validate(teams, custom):
    if not isinstance(teams,list) or len(teams)!=2:
        raise ValueError("비교할 편성 A와 B가 필요합니다.")
    preset = isinstance(custom,dict) and 'preset' in custom
    if preset and custom != leona_circus.PRESET:
        raise ValueError("확정 스킬 모델의 데이터가 맞지 않습니다. 레오나 이격 확정안을 다시 선택하세요.")
    if not isinstance(custom,dict) or set(custom)!={"name","base","stage","cooldown","effects"} | ({'preset'} if preset else set()):
        raise ValueError("사용자 정의 캐릭터 설정이 올바르지 않습니다.")
    if not isinstance(custom["name"],str) or not 1<=len(custom["name"].strip())<=50:
        raise ValueError("시험 캐릭터 이름을 1~50자로 입력하세요.")
    if custom["base"] not in bm._NIKKE or custom["base"] not in bm._PARSED_SKILLS:
        raise ValueError("시험 캐릭터의 기본 능력치 원본을 선택하세요.")
    if custom["stage"] not in ("1","2","3"):
        raise ValueError("시험 캐릭터의 버스트 단계는 1·2·3 중 하나입니다.")
    numeric(custom["cooldown"], 10, 120, "시험 캐릭터 쿨타임")
    if not isinstance(custom["effects"],list) or not (0 if preset else 1)<=len(custom["effects"])<=12:
        raise ValueError("시험 스킬 효과는 1~12개까지 가능합니다.")
    for e in custom["effects"]:
        if not isinstance(e,dict) or set(e)!={"stat","value","trigger","target","duration","n"}:
            raise ValueError("스킬 효과 입력 형식이 잘못되었습니다.")
        if e["stat"] not in STATS or e["trigger"] not in TRIGGERS or e["target"] not in TARGETS:
            raise ValueError("지원되지 않는 스킬 효과·조건·대상입니다.")
        numeric(e["value"],0,STATS[e["stat"]][2],STATS[e["stat"]][0])
        numeric(e["n"],1,120,"발동 간격",integral=e["trigger"]=="shots")
        numeric(e["duration"],-1,180,"지속 시간")
        if e["duration"] <= 0 and e["duration"] != -1:
            raise ValueError("지속 시간은 양수 또는 -1(계속 유지)입니다.")
        typ=STATS[e["stat"]][1]
        if (typ=="damage") != (e["target"]=="all_enemies"):
            raise ValueError("대미지 효과는 적 전체, 지원 효과는 아군 대상을 선택해야 합니다.")
        if typ != "buff" and e["trigger"]=="passive":
            raise ValueError("회복·직접 대미지는 상시가 아닌 반복 또는 이벤트 조건을 선택하세요.")
    for idx, team in enumerate(teams):
        label="AB"[idx]
        if not isinstance(team,dict) or not {"members","no_burst","every3"} <= set(team) or set(team)-{"members","no_burst","every3","favorites","curtain_cycles"}:
            raise ValueError(f"{label} 편성 설정이 잘못되었습니다.")
        ns=team["members"]
        if not isinstance(ns,list) or len(ns)!=5 or any(not isinstance(n,str) for n in ns) or len(set(ns))!=5:
            raise ValueError(f"{label}: 서로 다른 캐릭터 5명을 골라주세요.")
        for n in ns:
            if n!=CUSTOM and (n not in bm._NIKKE or n not in bm._PARSED_SKILLS):
                raise ValueError(f"{label}: 데이터에 없는 캐릭터 {n}")
        favorites=team.get("favorites",{})
        if not isinstance(favorites,dict) or any(n not in ns or not bm._NIKKE.get(n,{}).get("favorite_slots") or type(enabled) is not bool for n,enabled in favorites.items()):
            raise ValueError(f"{label}: 애장품은 해당 편성의 지원 캐릭터에 ON/OFF로 지정하세요.")
        if CUSTOM in ns and custom["base"] in ns:
            raise ValueError(f"{label}: 현재 시험안은 '{custom['base']}'의 데이터를 임시 사용하므로 원본과 같은 편성에는 넣을 수 없습니다. 다른 원본을 선택하세요.")
        for field in ["no_burst","every3"]:
            if team[field] and team[field] not in ns:
                raise ValueError(f"{label}: 버스트 운용 대상이 편성에 없습니다.")
        if team["no_burst"] and team["no_burst"]==team["every3"]:
            raise ValueError(f"{label}: 같은 캐릭터를 버스트 제외와 3회 우선에 동시에 지정할 수 없습니다.")
        cycles = team.get('curtain_cycles',[])
        if not isinstance(cycles,list) or len(cycles)>100 or any(type(n) is not int or not 1<=n<=100 for n in cycles) or len(cycles)!=len(set(cycles)):
            raise ValueError(f"{label}: 커튼콜 회차는 중복 없는 1~100 정수입니다.")
        if cycles and (not preset or CUSTOM not in ns or team['no_burst']==CUSTOM or team['every3']):
            raise ValueError(f"{label}: 커튼콜 회차 지정 시 확정안을 편성하고 해당 캐릭터 버스트 제외·3회 우선을 해제하세요.")

def compile_effects(custom):
    out=[]
    for i,e in enumerate(custom["effects"]):
        typ=STATS[e["stat"]][1]
        trigger=e["trigger"]
        timing=f"on_attack_count:{int(e['n'])}" if trigger=="shots" else f"every:{e['n']:g}s" if trigger=="time" else trigger
        item={"source":"스킬3" if trigger=="burst_cast" else "스킬1", "type":typ,
            "name":f"시험안 {i+1} · {STATS[e['stat']][0]}", "trigger":{"timing":[timing],"condition":[]},
            "target":e["target"],"stat":"received_dmg_pct" if e["stat"]=="damage_reduction" else e["stat"],
            "fixed_value":-e["value"] if e["stat"]=="damage_reduction" else e["value"]}
        if typ=="buff": item.update(duration=-1 if trigger=="passive" else e["duration"],polarity="beneficial")
        if e["stat"]=="heal_hp_pct":item["scaling"]="max_hp"
        out.append(item)
    return out
