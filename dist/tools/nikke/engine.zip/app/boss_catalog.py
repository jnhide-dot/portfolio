"""Public Enikk snapshot, not a reconstructed fight timeline."""
import json
import re
from functools import lru_cache
from pathlib import Path

SOURCE = Path(__file__).parent / 'boss-data/enikk-soloraids-20261030.json'
ELEMENTS = {'Wind':'풍압','Fire':'작열','Water':'수냉','Electronic':'전격','Iron':'철갑'}
NAMES = {'Mother Whale':'마더 웨일','Black Smith':'블랙스미스','Harvester':'하베스터',
    'Alteisen':'알트아이젠','Modernia':'모더니아','Ultra':'울트라','Chatterbox':'토커티브',
    'Material H':'마테리얼 H','Crystal Chamber':'크리스탈 체임버','Storm Bringer':'스톰 브링어',
    'Nihilister':'니힐리스타','Indivilia':'인디빌리아','Grave Digger':'그레이브 디거',
    'Golden Kraken':'골든 크라켄','Mirror Container':'미러 컨테이너','Land Eater':'랜드 이터',
    'Behemoth':'베히모스','Luxurious Spider':'사치스러운 거미'}

# A table row is not necessarily a complete attack: timeline/condition rows may
# trigger additional assets. Keep the raw evidence, never silently guess targets.
def parse_skill(k, raid):
    name=k.get('name_localkey') or f"미명명 공격 #{k['id']}"
    description=k.get('description_localkey') or ''
    fire=k.get('fire_type')
    all_text=bool(re.search(r'(?:all Nikkes|all the Nikkes)',description,re.I))
    target='all' if fire=='InstantAll' or (fire=='InstantAll_FrontRay' and all_text) else {
        'HighAttack':'top_atk:1','Random':'random:1'}.get(k.get('prefer_target'))
    issues=[]
    conditional=[]
    if k.get('cancel_type') not in (None,'None'):
        conditional.append('저지·파츠 파괴에 따른 취소 분기')
    if re.search(r'interrupted|interruption|cancel rings?|otherwise|once they|after .*stabbed',description,re.I):
        conditional.append('설명에 명시된 저지·파괴·선행 공격 조건')
    if raid==40 and name in ('Luxurious Radiance','Luxurious Light','Luxurious Body'):
        conditional.append('S40 전용 패턴 분기')
    if not k.get('name_localkey'):issues.append('미명명 내부 스킬: 호출 관계 미확인')
    if re.search(r'lethal damage',description,re.I):issues.append('치명적 공격: 단일 계수만으로 전체 피해를 확정할 수 없음')
    if all_text and fire not in ('InstantAll','InstantAll_FrontRay'):
        issues.append('설명은 전체 공격이나 원본 발사 형식은 단일: 연계 스킬 확인 필요')
    if not target:issues.append('미지원 표적 규칙: '+str(k.get('prefer_target')))
    if fire not in ('Instant','InstantAll','InstantAll_FrontRay','ProjectileCurve','ProjectileCurveV2'):
        issues.append('미지원 발사 형식: '+str(fire))
    if fire=='InstantAll_FrontRay' and not all_text:
        issues.append('전방 광선의 실제 피격 범위 미확인')
    coeff=k.get('skill_value_01',0)/100
    hits=k.get('shot_count',0)
    if k.get('skill_value_type_01')!='Percent' or not 0<coeff<=10000:issues.append('직접 피해 계수 미확인')
    if not 1<=hits<=10:issues.append('테이블 타수 미지원')
    if k.get('target_character_ratio',0)<=0:issues.append('캐릭터 직접 피격 항목 아님')
    spec=None if issues else {'coeff':coeff,'target':target,'hits':hits,'pierce':bool(k.get('penetration'))}
    return {'id':k['id'],'name':name,'description':description,'spec':spec,
        'fire_type':fire,'shot_timing':k.get('shot_timing'),
        'conditional':bool(conditional),'condition_reasons':conditional,'issues':issues,
        'interceptable':k.get('is_destroyable_projectile',False),
        'raw':{f:k.get(f) for f in ('fire_type','prefer_target','shot_count','shot_timing',
            'target_count','target_character_ratio','target_cover_ratio','target_nothing_ratio',
            'skill_value_type_01','skill_value_01','skill_value_type_02','skill_value_02',
            'is_using_timeline','cancel_type','casting_time','delay_time')},
        'validation':{'damage':'unverified','timing':'unverified','hit_count':'table_only'}}


@lru_cache(maxsize=1)
def catalog():
    import boss_core
    records=json.loads(SOURCE.read_text(encoding='utf-8-sig'))['data']['soloraids']
    result=[]
    for row in records:
        m,s=row['monster_obj'],row['stats']
        english=m['name_localkey']
        base=english.rsplit(' ',1)[0]
        skills=[parse_skill(e['skill_obj'],row['raid_number']) for e in m.get('skill_data',[])
                if e.get('skill_obj') and e['skill_obj'].get('id')]
        parts=[{'name':p['parts_name_localkey'],'hp':p.get('hp')} for p in row.get('parts_obj',[]) if p.get('parts_name_localkey')]
        result.append({'id':f"s{row['raid_number']}",'raid':row['raid_number'],'name':NAMES.get(base,base),
            'source_name':english,'level':s['lv'],'atk':s['level_attack']*m['attack_ratio']/10000,
            'def':s['level_defence']*m['defence_ratio']/10000,'hp':s['level_hp']*m['hp_ratio']/10000,
            'code':ELEMENTS[m['element_id']['element']],'skills':skills,'parts':parts,'core':boss_core.metadata(row),
            'raw_stat_damage_ratio':s.get('level_statdamageratio'),
            'damage_validated':False,'source':'https://enikk.app/soloraid','collected':'2026-10-30',
            'timeline_available':False, 'pattern_model':'spider' if row['raid_number']==40 else 'library',
            'battle_time':row.get('wave_obj',{}).get('battle_time',180)})
    for boss in result:
        boss['model_summary']=pattern_profile(boss)
    return result

def find(key):
    return next((r for r in catalog() if r['id']==key),None)


def pattern_profile(boss):
    """A reproducible boss-specific partial model. AI timing is explicitly synthetic."""
    if boss['raid']==40:
        return {'kind':'video','label':'영상 기반 · 근사', 'level':400,
                'timing_basis':'기존 영상 기반 S40 스크립트', 'attacks':[], 'excluded':[],
                'damage_validated':False, 'timing_validated':False,
                'limitations':['피해량 실측 검증 전: 생존·힐 필요성 판단에 사용 불가','일부 저지·좌표·소환 수치는 추정값','미사일 요격 미재현']}
    attacks=[];excluded=[]
    for skill in boss['skills']:
        if not skill['spec']:
            excluded.append({'name':skill['name'],'reason':' / '.join(skill['issues'])})
        elif skill['conditional']:
            excluded.append({'name':skill['name'],'reason':' / '.join(skill['condition_reasons'])})
        else:
            attacks.append({'name':skill['name'],'skill_id':skill['id'], 'spec':skill['spec'],
                'interceptable':skill['interceptable'], 'interval':.3})
    cycle=max(30,len(attacks)*8)
    for i,attack in enumerate(attacks):
        attack.update(start=8+i*8,every=cycle)
    return {'kind':'data','label':'자료 공격 시험 · 실전 미검증', 'level':boss['level'],
            'timing_basis':f'테이블 목록 순서로 첫 8초부터 8초씩 배치, 각 공격 {cycle}초 반복, 연타 0.3초. 실제 AI 순서 아님.',
            'attacks':attacks,'excluded':excluded,
            'damage_validated':False, 'timing_validated':False,
            'limitations':['피해 계산식·계수 적용을 실전 피격량과 대조하지 않음','공격 순서·주기는 가정값','요격 가능 공격도 전부 피격하는 조건',
                '저지·파츠 파괴·소환·부가 효과·코어·거리 변화·레벨 상승 미재현',
                '테이블 타수와 실전 발사체 수는 다를 수 있음']}
