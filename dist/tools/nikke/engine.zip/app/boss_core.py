"""Core evidence is separate from the dimensions/windows used by the simulator."""
import copy
import json
from pathlib import Path

OVERRIDES = Path(__file__).parent / 'boss-data/core-evidence-20261102.json'

def metadata(row):
    raid=row['raid_number']
    parts=[p['parts_name_localkey'] for p in row.get('parts_obj',[]) if 'core' in (p.get('parts_name_localkey') or '').lower()]
    out=dict(status='part_record' if parts else 'unknown',
             label='코어 명칭 파츠 기록 있음' if parts else '코어 유무 미확인',
             parts=parts, size_px=None, windows=None, measured=False,
             note='파츠 목록은 코어 명중 판정·노출 시간·크기를 확정하지 않습니다.' if parts else '코어 이름의 파츠가 없다는 이유로 코어 없음으로 단정하지 않습니다.',
             sources=[{'title':'Enikk 보스 파츠 자료', 'url':f'https://enikk.app/soloraid/{raid}'}],
             checked='2026-11-02')
    overrides=json.loads(OVERRIDES.read_text(encoding='utf-8'))
    out.update(overrides.get(str(raid),{}))
    return out

def resolved(p):
    import boss_catalog
    key='s40' if p['boss']=='spider' else p['boss_source']
    boss=boss_catalog.find(key) if key else None
    evidence=copy.deepcopy(boss['core']) if boss else None
    mode=p.get('core_mode','reference')
    windows=p.get('core_windows',[])
    if mode=='manual':
        px=p['core_px']
        message=f'사용자 가정: 코어 {px}px · '+('지정 구간 노출' if windows else '전투 내내 노출')+' (실측값 아님)'
    elif mode=='none':
        px=0;windows=[];message='사용자 선택: 코어 효과 제외'
    elif evidence and evidence['status']=='absent':
        px=0;windows=[];message='보스 참고 자료: 코어 없음 · 코어 효과 제외'
    else:
        px=0;windows=[];message='코어 크기·노출 구간 미확인 → 코어 효과 제외한 가정으로 계산. 실제 코어 없음이라는 뜻이 아닙니다.'
    active=[{'start':s,'end':min(e,p['duration'])} for s,e in windows if s<p['duration']]
    return dict(mode=mode,boss_id=key or None,size_px=px,windows=active,
                whole_fight=bool(px and not windows),evidence=evidence,message=message,
                accuracy='user_assumption' if mode=='manual' else 'reference_no_core' if evidence and evidence['status']=='absent' and mode=='reference' else 'core_excluded')

def apply(enemy,p):
    info=resolved(p)
    enemy['core_px']=info['size_px'] if info['whole_fight'] else 0
    if info['size_px'] and not info['whole_fight']:
        for i,w in enumerate(info['windows']):
            enemy.setdefault('patterns',[]).append(dict(id=f'사용자 코어 구간 {i+1}',kind='core',
                after=['start'],delay=w['start'],until={'time':w['end']-w['start']},core_px=info['size_px']))
    return enemy
